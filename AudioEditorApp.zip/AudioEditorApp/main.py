
import sys
import os
from moviepy.editor import VideoFileClip
from pydub import AudioSegment, effects, silence

# Function: Remove silence from audio
def remove_silence(audio_path, output_path, silence_thresh=-50, min_silence_len=700):
    sound = AudioSegment.from_file(audio_path, format="wav")
    chunks = silence.split_on_silence(sound,
                                      min_silence_len=min_silence_len,
                                      silence_thresh=sound.dBFS + silence_thresh)
    processed_audio = AudioSegment.empty()
    for chunk in chunks:
        processed_audio += chunk
    processed_audio.export(output_path, format="wav")
    print(f"✅ Silence removed: {output_path}")

# Function: Denoise (normalize)
def denoise_audio(input_path, output_path):
    sound = AudioSegment.from_file(input_path, format="wav")
    normalized = effects.normalize(sound)
    normalized.export(output_path, format="wav")
    print(f"✅ Noise reduced: {output_path}")

# Function: Convert Video to Audio
def video_to_audio(video_path, output_audio):
    clip = VideoFileClip(video_path)
    clip.audio.write_audiofile(output_audio)
    print(f"✅ Extracted audio: {output_audio}")

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Usage: python main.py <command> <input_file> [output_file]")
        print("Commands: remove_silence, denoise, video2audio")
        sys.exit(1)

    command = sys.argv[1]
    input_file = sys.argv[2]
    output_file = sys.argv[3] if len(sys.argv) > 3 else "output.wav"

    if command == "remove_silence":
        remove_silence(input_file, output_file)
    elif command == "denoise":
        denoise_audio(input_file, output_file)
    elif command == "video2audio":
        video_to_audio(input_file, output_file)
    else:
        print("❌ Unknown command")
